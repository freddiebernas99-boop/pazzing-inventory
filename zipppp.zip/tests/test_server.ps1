$testPort = 8000
Write-Host "Testing Pazings server files..."

# Test HTML syntax and presence
$html = Get-Content -Raw "c:\PAZINGS-INVENTORY\public\index.html"
if ($html -match "PAZINGS" -and $html -match "Daily Overview" -and $html -match "Water Refilling") {
    Write-Host "Index HTML verification: PASSED"
} else {
    Write-Host "Index HTML verification: FAILED"
}

# Test JS syntax and modules
$js = Get-Content -Raw "c:\PAZINGS-INVENTORY\public\assets\js\app.js"
if ($js -match "DataService" -and $js -match "calculateWaterTotal" -and $js -match "calculateLaundryTotal") {
    Write-Host "App JS verification: PASSED"
} else {
    Write-Host "App JS verification: FAILED"
}

# Test CSS presence
$css = Get-Content -Raw "c:\PAZINGS-INVENTORY\public\assets\css\style.css"
if ($css -match "#123B66" -and $css -match "#2563EB" -and $css -match "#F5F7FA") {
    Write-Host "CSS Palette verification: PASSED"
} else {
    Write-Host "CSS Palette verification: FAILED"
}

# Test Firestore rules
$rules = Get-Content -Raw "c:\PAZINGS-INVENTORY\firestore.rules"
if ($rules -match "rules_version = '2'" -and $rules -match "match /transactions/{transId}") {
    Write-Host "Firestore Rules verification: PASSED"
} else {
    Write-Host "Firestore Rules verification: FAILED"
}
