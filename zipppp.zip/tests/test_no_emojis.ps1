$files = @(
    "c:\PAZINGS-INVENTORY\public\index.html",
    "c:\PAZINGS-INVENTORY\public\assets\js\app.js",
    "c:\PAZINGS-INVENTORY\public\assets\css\style.css",
    "c:\PAZINGS-INVENTORY\public\assets\js\firebase-config.js"
)

$hasErrors = $false
foreach ($filePath in $files) {
    $content = Get-Content -Raw $filePath
    # Check for unicode surrogate pairs (common emojis)
    for ($i = 0; $i -lt $content.Length; $i++) {
        $code = [int]$content[$i]
        if ($code -ge 0xD800 -and $code -le 0xDBFF) {
            Write-Host "EMOJI DETECTED in $filePath at position $i"
            $hasErrors = $true
            break
        }
    }
}

if (-not $hasErrors) {
    Write-Host "ZERO EMOJIS CONFIRMED across all client files!"
} else {
    exit 1
}
