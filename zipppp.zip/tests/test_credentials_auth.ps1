Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "  TESTING FIREBASE ACCOUNT AUTHENTICATION" -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan

$nodeScript = @'
const fs = require('fs');
const jsCode = fs.readFileSync('public/assets/js/app.js', 'utf8');
const html = fs.readFileSync('public/index.html', 'utf8');
const rules = fs.readFileSync('firestore.rules', 'utf8');
const localStorageStore = {
    pazings_users: JSON.stringify([
        { id: 'usr_owner_1', email: 'legacy-owner@example.test', passwordHash: 'legacy-owner-password' },
        { id: 'legacy_staff', email: 'staff@example.test', passwordHash: 'legacy-staff-password' }
    ]),
    pazings_security_credentials: JSON.stringify({ staffPinHash: 'legacy-hash' }),
    pazings_session_user: JSON.stringify({ id: 'usr_owner_1', role: 'owner' })
};
const window = { crypto: null, isSecureContext: false, scrollTo() {} };
const localStorage = {
    getItem(key) { return localStorageStore[key] || null; },
    setItem(key, value) { localStorageStore[key] = String(value); },
    removeItem(key) { delete localStorageStore[key]; }
};
const document = {
    readyState: 'complete',
    getElementById() { return null; },
    querySelectorAll() { return []; },
    addEventListener() {}
};
let provisionedPassword = null;
const firebase = {
    firestore: { FieldValue: { serverTimestamp() { return 'server timestamp'; } } },
    initializeApp() {
        return {
            auth() {
                return {
                    async createUserWithEmailAndPassword(email, password) {
                        provisionedPassword = password;
                        return { user: { uid: 'newStaffUid', async delete() {} } };
                    },
                    async signOut() {}
                };
            },
            async delete() {}
        };
    }
};
window.firebaseConfig = {};

eval(jsCode);
const DataService = window.DataService;
const AppState = window.AppState;

async function run() {
    let passed = 0;
    let failed = 0;
    function assert(condition, description) {
        if (condition) {
            console.log('[PASS] ' + description);
            passed++;
        } else {
            console.error('[FAIL] ' + description);
            failed++;
        }
    }

    assert(!/Pazings(?:Staff|Owner)\d{4}!|(?:Password|Staff)\d+!|DEFAULT_(?:STAFF|ADMIN)_.*HASH/.test(jsCode), 'Client code contains no shipped authentication defaults');
    assert(!/staff-pin|admin-passphrase|change-staff-pin-form|change-admin-passphrase-form/.test(html), 'UI no longer uses shared PINs or passphrases');
    assert(!/isOwnerTerminal|isStaffTerminal|isAuthEmail/.test(rules), 'Firestore rules do not grant roles based on email patterns');
    assert(/allow create: if isOwner\(\) && isValidUser/.test(rules), 'Only a provisioned owner can create user profiles');
    assert(!/allow read: if isAuthenticated\(\);/.test(rules), 'Unprofiled Firebase accounts cannot read business collections');
    assert(/settingId != 'security_credentials'/.test(rules), 'Firestore blocks access to the retired credential document');
    const migratedUsers = JSON.parse(localStorageStore.pazings_users);
    assert(migratedUsers.length === 1 && !('passwordHash' in migratedUsers[0]), 'Legacy local passwords and seeded accounts are removed on migration');
    assert(!('pazings_security_credentials' in localStorageStore), 'Legacy local PIN/passphrase hashes are removed on migration');
    assert(!('pazings_session_user' in localStorageStore), 'Legacy seeded owner session is removed on migration');

    AppState.isLiveFirestore = false;
    const demoLogin = await DataService.loginDemo('owner');
    assert(demoLogin.success && demoLogin.user.role === 'owner', 'Local owner demo can be opened without a password');
    assert(!JSON.stringify(localStorageStore).includes('passwordHash'), 'Local demo does not store user passwords');
    assert(!(await DataService.loginDemo('invalid')).success, 'Local demo rejects unknown roles');

    const profiles = {
        ownerUid: { email: 'owner@example.test', fullName: 'Owner', role: 'owner', status: 'active' },
        staffUid: { email: 'staff@example.test', fullName: 'Staff', role: 'staff', status: 'active' },
        inactiveUid: { email: 'inactive@example.test', fullName: 'Inactive', role: 'staff', status: 'inactive' }
    };
    let signedOut = false;
    AppState.isLiveFirestore = true;
    AppState.auth = {
        currentUser: null,
        async signInWithEmailAndPassword(email, password) {
            if (password !== 'valid-password') throw new Error('invalid credential');
            const uid = email.startsWith('owner') ? 'ownerUid' : email.startsWith('inactive') ? 'inactiveUid' : 'staffUid';
            this.currentUser = { uid, email };
            return { user: this.currentUser };
        },
        async signOut() {
            signedOut = true;
            this.currentUser = null;
        },
        onAuthStateChanged(callback) {
            this.listener = callback;
            callback(this.currentUser);
        }
    };
    AppState.db = {
        collection() {
            return {
                doc(uid) {
                    return {
                        async get() {
                            return profiles[uid]
                                ? { exists: true, data: () => profiles[uid] }
                                : { exists: false };
                        }
                    };
                }
            };
        }
    };

    const staffLogin = await DataService.loginWithCredentials('staff@example.test', 'valid-password', 'staff');
    assert(staffLogin.success && AppState.currentUser.role === 'staff', 'Staff login uses its provisioned Firebase profile');
    const wrongRole = await DataService.loginWithCredentials('staff@example.test', 'valid-password', 'owner');
    assert(!wrongRole.success && signedOut, 'A role mismatch is denied and Firebase signs out');
    const inactive = await DataService.loginWithCredentials('inactive@example.test', 'valid-password', 'staff');
    assert(!inactive.success, 'Inactive Firebase profiles are denied');
    const invalidPassword = await DataService.loginWithCredentials('staff@example.test', 'bad-password', 'staff');
    assert(!invalidPassword.success, 'Invalid Firebase credentials are denied');

    AppState.auth.currentUser = { uid: 'missingUid', email: 'owner@example.test' };
    const missingProfile = await DataService.initAuth();
    assert(missingProfile === null, 'A matching email cannot grant owner access without a Firestore profile');

    let savedStaffProfile = null;
    AppState.currentUser = { id: 'ownerUid', role: 'owner' };
    AppState.db = {
        collection() {
            return {
                doc(uid) {
                    return {
                        async set(profile) {
                            assert(uid === 'newStaffUid', 'Staff profile uses the Firebase Authentication UID');
                            savedStaffProfile = profile;
                        }
                    };
                }
            };
        }
    };
    const createdStaff = await DataService.createUser('New Staff', 'new-staff@example.test', 'unique-password', 'staff');
    assert(createdStaff.id === 'newStaffUid' && savedStaffProfile.role === 'staff', 'Owner can provision an individual staff profile');
    assert(provisionedPassword === 'unique-password' && !JSON.stringify(savedStaffProfile).includes(provisionedPassword), 'Staff password is sent to Firebase Auth and never stored in Firestore');

    console.log(`\nResults: ${passed} passed, ${failed} failed`);
    if (failed) process.exit(1);
}

run().catch(error => {
    console.error(error);
    process.exit(1);
});
'@

$nodeScript | node
if ($LASTEXITCODE -ne 0) {
    Write-Host "[FAIL] Firebase auth tests failed." -ForegroundColor Red
    exit 1
}

Write-Host "[PASS] Firebase account authentication tests passed." -ForegroundColor Green
