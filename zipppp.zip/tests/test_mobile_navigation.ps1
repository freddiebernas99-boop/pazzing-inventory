# Verification Test: Mobile Navigation Dropdown & Accessibility
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "  TESTING MOBILE NAVIGATION DROPDOWN & FUNCTIONALITY" -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan

$html = Get-Content "c:\PAZINGS-INVENTORY\public\index.html" -Raw
$css = Get-Content "c:\PAZINGS-INVENTORY\public\assets\css\style.css" -Raw
$js = Get-Content "c:\PAZINGS-INVENTORY\public\assets\js\app.js" -Raw

$allPassed = $true

function Assert-Contains($content, $pattern, $label) {
    if ($content -match $pattern) {
        Write-Host "[PASS] $label" -ForegroundColor Green
    } else {
        Write-Host "[FAIL] $label - Pattern not found: $pattern" -ForegroundColor Red
        $global:allPassed = $false
    }
}

# 1. HTML Semantic & Accessibility Verification
Write-Host "`n--- 1. Navigation HTML & ARIA Attributes ---" -ForegroundColor Yellow
Assert-Contains $html 'id="navToggle"' "Menu toggle button present (id='navToggle')"
Assert-Contains $html 'aria-label="Toggle navigation"' "aria-label present on navToggle"
Assert-Contains $html 'aria-expanded="false"' "aria-expanded present on navToggle"
Assert-Contains $html 'aria-controls="navLinks"' "aria-controls present on navToggle"
Assert-Contains $html 'class="nav-actions"' "nav-actions positioning container present"
Assert-Contains $html 'id="navLinks"' "Navigation links container present (id='navLinks')"

# All 8 Navigation items present with data-view
$destinations = @('dashboard', 'water', 'laundry', 'expenses', 'reports', 'customers', 'rates', 'staff')
foreach ($dest in $destinations) {
    Assert-Contains $html "data-view=`"$dest`"" "Navigation button for view '$dest' present"
}
Assert-Contains $html 'id="logout-btn"' "Logout button present (id='logout-btn')"
Assert-Contains $html 'id="nav-brand"' "Brand logo present (id='nav-brand')"

# 2. CSS Dropdown Verification
Write-Host "`n--- 2. Dropdown CSS Styling & Positioning ---" -ForegroundColor Yellow
Assert-Contains $css '(?s)\.nav-actions\s*\{.*?position:\s*relative' "nav-actions positioned relatively"
Assert-Contains $css '(?s)@media\s*\(max-width:\s*768px\).*?\.nav-links\s*\{.*?position:\s*absolute' "Mobile dropdown positioned absolutely"
Assert-Contains $css '(?s)@media\s*\(max-width:\s*768px\).*?\.nav-links\s*\{.*?right:\s*0' "Mobile dropdown aligned to right edge"
Assert-Contains $css '(?s)@media\s*\(max-width:\s*768px\).*?\.nav-links\s*\{.*?width:\s*220px' "Compact dropdown width (220px) specified"
Assert-Contains $css '(?s)@media\s*\(max-width:\s*768px\).*?\.nav-links\s*\{.*?z-index:\s*1050' "High z-index (1050) applied above content"
Assert-Contains $css '(?s)\.nav-item-logout\s*button\s*\{.*?color:\s*var\(--danger\)' "Logout button styled with danger color"

# 3. JavaScript Dropdown Logic & Interaction
Write-Host "`n--- 3. JavaScript Dropdown Logic & Interaction ---" -ForegroundColor Yellow
Assert-Contains $js 'function closeMobileMenu\(' "closeMobileMenu function defined"
Assert-Contains $js 'function openMobileMenu\(' "openMobileMenu function defined"
Assert-Contains $js 'function toggleMobileMenu\(' "toggleMobileMenu function defined"
Assert-Contains $js '(?s)btn\.addEventListener\(''click''.*?closeMobileMenu\(\)' "nav-link click listener closes mobile menu"
Assert-Contains $js '(?s)data-nav.*?closeMobileMenu\(\)' "data-nav action shortcuts close mobile menu"
Assert-Contains $js '(?s)switchView\(viewName\)\s*\{.*?closeMobileMenu\(\)' "switchView unconditionally guarantees menu closure"
Assert-Contains $js 'toggleBtn\.setAttribute\(''aria-expanded''' "Toggle button updates aria-expanded"
Assert-Contains $js 'document\.addEventListener\(''click''' "Click-outside document listener registered"
Assert-Contains $js 'document\.addEventListener\(''keydown''' "Escape key listener registered"
Assert-Contains $js 'window\.addEventListener\(''resize''' "Window resize listener registered"

# 4. Zero Emojis Check
Write-Host "`n--- 4. Zero Emojis Policy Enforcement ---" -ForegroundColor Yellow
$emojiRegex = '[\uD83C-\uDBFF\uDC00-\uDFFF\u2600-\u26FF\u2700-\u27BF]'
if ($html -match $emojiRegex -or $css -match $emojiRegex -or $js -match $emojiRegex) {
    Write-Host "[FAIL] Found emoji in navigation files!" -ForegroundColor Red
    $allPassed = $false
} else {
    Write-Host "[PASS] Zero emojis confirmed in all navigation code" -ForegroundColor Green
}

if ($allPassed) {
    Write-Host "`n========================================================" -ForegroundColor Green
    Write-Host "  ALL MOBILE NAVIGATION TESTS PASSED SUCCESSFULLY!" -ForegroundColor Green
    Write-Host "========================================================" -ForegroundColor Green
    exit 0
} else {
    Write-Host "`n[ERROR] Some navigation checks failed." -ForegroundColor Red
    exit 1
}
