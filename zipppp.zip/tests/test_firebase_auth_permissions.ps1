Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "  TESTING FIREBASE AUTH FAILURE HANDLING" -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan

$testJs = @'
const fs = require('fs');
const jsCode = fs.readFileSync('public/assets/js/app.js', 'utf8');
const localStorageStore = {};
const window = { crypto: null, isSecureContext: false, scrollTo() {} };
const localStorage = {
    getItem(key) { return localStorageStore[key] || null; },
    setItem(key, value) { localStorageStore[key] = String(value); },
    removeItem(key) { delete localStorageStore[key]; }
};
const document = {
    readyState: 'complete',
    getElementById() { return null; },
    querySelectorAll() { return []; },
    addEventListener() {}
};

eval(jsCode);
const DataService = window.DataService;
const AppState = window.AppState;

async function run() {
    let passed = 0;
    let failed = 0;
    function assert(condition, description) {
        if (condition) {
            console.log('[PASS] ' + description);
            passed++;
        } else {
            console.error('[FAIL] ' + description);
            failed++;
        }
    }

    AppState.isLiveFirestore = true;
    AppState.db = {
        collection() {
            return {
                doc() {
                    return {
                        async get() {
                            const error = new Error('Missing or insufficient permissions.');
                            error.code = 'permission-denied';
                            throw error;
                        }
                    };
                }
            };
        }
    };
    let signOutCount = 0;
    AppState.auth = {
        currentUser: null,
        async signInWithEmailAndPassword(email, password) {
            this.currentUser = { uid: 'uid1', email };
            return { user: this.currentUser };
        },
        async signOut() {
            signOutCount++;
            this.currentUser = null;
        }
    };

    const permissionDenied = await DataService.loginWithCredentials('owner@example.test', 'password', 'owner');
    assert(!permissionDenied.success && permissionDenied.message.includes('permissions'), 'Firestore profile permission errors fail sign-in visibly');
    assert(signOutCount === 1 && AppState.auth.currentUser === null, 'Firebase session is cleared when profile verification fails');

    AppState.auth.signInWithEmailAndPassword = async () => {
        const error = new Error('Email/password provider disabled.');
        error.code = 'auth/operation-not-allowed';
        throw error;
    };
    const providerDisabled = await DataService.loginWithCredentials('user@example.test', 'password', 'staff');
    assert(!providerDisabled.success && providerDisabled.message.includes('not enabled'), 'Disabled provider has an actionable error');

    AppState.auth.signInWithEmailAndPassword = async () => {
        const error = new Error('A network error occurred.');
        error.code = 'auth/network-request-failed';
        throw error;
    };
    const networkFailure = await DataService.loginWithCredentials('user@example.test', 'password', 'staff');
    assert(!networkFailure.success && networkFailure.message.includes('Network error'), 'Network failures are reported clearly');

    console.log(`\nResults: ${passed} passed, ${failed} failed`);
    if (failed) process.exit(1);
}

run().catch(error => {
    console.error(error);
    process.exit(1);
});
'@

$testJs | node
if ($LASTEXITCODE -ne 0) {
    Write-Host "[FAIL] Firebase auth error-handling tests failed." -ForegroundColor Red
    exit 1
}

Write-Host "[PASS] Firebase auth error-handling tests passed." -ForegroundColor Green
