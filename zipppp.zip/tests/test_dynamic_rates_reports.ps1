# Verification Test: Dynamic Rates, Reports Side-by-Side Breakdown, Login Redesign & Responsiveness
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "  VERIFYING DYNAMIC RATES, REPORTS & LOGIN ARCHITECTURE" -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan

$html = Get-Content "c:\PAZINGS-INVENTORY\public\index.html" -Raw
$css = Get-Content "c:\PAZINGS-INVENTORY\public\assets\css\style.css" -Raw
$js = Get-Content "c:\PAZINGS-INVENTORY\public\assets\js\app.js" -Raw

$allPassed = $true

function Assert-Contains($content, $pattern, $label) {
    if ($content -match $pattern) {
        Write-Host "[PASS] $label" -ForegroundColor Green
    } else {
        Write-Host "[FAIL] $label - Not found: $pattern" -ForegroundColor Red
        $global:allPassed = $false
    }
}

# 1. Check Login UI Elements
Write-Host "`n--- 1. Login Redesign Verification ---" -ForegroundColor Yellow
Assert-Contains $html 'id="login-role-select"' "Role selection screen container present"
Assert-Contains $html 'id="btn-select-staff"' "Staff Portal selection button present"
Assert-Contains $html 'id="btn-select-admin"' "Admin Portal selection button present"
Assert-Contains $html 'id="login-staff-card"' "Staff Login card present"
Assert-Contains $html 'id="login-admin-card"' "Admin Login card present"
Assert-Contains $html 'id="staff-login-form"' "Staff Login form present"
Assert-Contains $html 'id="admin-login-form"' "Admin Login form present"
Assert-Contains $html 'id="btn-staff-back"' "Staff Back button present"
Assert-Contains $html 'id="btn-admin-back"' "Admin Back button present"

# Verify default credentials box is removed from index.html
if ($html -match 'id="demo-credentials-box"') {
    Write-Host "[FAIL] demo-credentials-box should NOT be present in index.html" -ForegroundColor Red
    $allPassed = $false
} else {
    Write-Host "[PASS] Default credentials box successfully removed from UI" -ForegroundColor Green
}

# 2. Dynamic Transaction Containers
Write-Host "`n--- 2. Dynamic Transaction Forms Verification ---" -ForegroundColor Yellow
Assert-Contains $html 'id="water-services-container"' "Water services dynamic container present"
Assert-Contains $html 'id="laundry-services-container"' "Laundry services dynamic container present"
Assert-Contains $js 'function renderWaterFormFields' "renderWaterFormFields function defined in JS"
Assert-Contains $js 'function renderLaundryFormFields' "renderLaundryFormFields function defined in JS"
Assert-Contains $js 'function calculateWaterTotal' "calculateWaterTotal function defined in JS"
Assert-Contains $js 'function calculateLaundryTotal' "calculateLaundryTotal function defined in JS"

# 3. Dynamic Service Rates Management (CRUD)
Write-Host "`n--- 3. Service Rates Management (CRUD) ---" -ForegroundColor Yellow
Assert-Contains $html 'id="btn-open-add-service"' "Add New Service button present"
Assert-Contains $html 'id="add-service-modal"' "Add Service Modal present"
Assert-Contains $html 'id="edit-service-modal"' "Edit Service Modal present"
Assert-Contains $html 'id="rates-water-tbody"' "Water rates table body present"
Assert-Contains $html 'id="rates-laundry-tbody"' "Laundry rates table body present"
Assert-Contains $js 'DEFAULT_SERVICES' "DEFAULT_SERVICES catalog defined"
Assert-Contains $js 'async getServices\(' "DataService.getServices defined"
Assert-Contains $js 'async addService\(' "DataService.addService defined"
Assert-Contains $js 'async updateService\(' "DataService.updateService defined"
Assert-Contains $js 'async deleteService\(' "DataService.deleteService defined"
Assert-Contains $js 'async toggleServiceActive\(' "DataService.toggleServiceActive defined"

# 4. Reports Side-by-Side Breakdown & Synchronized Filters
Write-Host "`n--- 4. Reports Side-by-Side Cards & Footers ---" -ForegroundColor Yellow
Assert-Contains $html 'id="rep-water-tx-card"' "Reports Water Transactions card present"
Assert-Contains $html 'id="rep-laundry-tx-card"' "Reports Laundry Transactions card present"
Assert-Contains $html 'id="rep-water-tx-tbody"' "Water transactions tbody present in Reports"
Assert-Contains $html 'id="rep-laundry-tx-tbody"' "Laundry transactions tbody present in Reports"
Assert-Contains $html 'id="rep-water-summary-count"' "Water count metric present in footer"
Assert-Contains $html 'id="rep-water-summary-gross"' "Water gross sales metric present in footer"
Assert-Contains $html 'id="rep-water-summary-paid"' "Water paid metric present in footer"
Assert-Contains $html 'id="rep-water-summary-unpaid"' "Water unpaid metric present in footer"
Assert-Contains $html 'id="rep-laundry-summary-count"' "Laundry count metric present in footer"
Assert-Contains $html 'id="rep-laundry-summary-gross"' "Laundry gross sales metric present in footer"
Assert-Contains $html 'id="rep-laundry-summary-paid"' "Laundry paid metric present in footer"
Assert-Contains $html 'id="rep-laundry-summary-unpaid"' "Laundry unpaid metric present in footer"

# 5. CSS Responsive Grid & Touch Targets
Write-Host "`n--- 5. Responsive Styling & Modals ---" -ForegroundColor Yellow
Assert-Contains $css '\.reports-tx-grid' "reports-tx-grid class styled in CSS"
Assert-Contains $css '\.modal-overlay' "modal-overlay styled in CSS"
Assert-Contains $css '\.role-select-btn' "role-select-btn styled in CSS"
Assert-Contains $css 'min-height:\s*44px' "44px minimum touch target enforced in CSS"
Assert-Contains $css '@media\s*\(max-width:\s*900px\)' "Responsive 900px breakpoint for grid stacking"

# 6. Admin Role Security Guard Check
Write-Host "`n--- 6. Admin Role Enforcement in JS ---" -ForegroundColor Yellow
Assert-Contains $js 'user\.role !== ''owner''' "Owner role enforcement check present in admin login"

if ($allPassed) {
    Write-Host "`n========================================================" -ForegroundColor Green
    Write-Host "  ALL VERIFICATION CHECKS PASSED SUCCESSFULLY!" -ForegroundColor Green
    Write-Host "========================================================" -ForegroundColor Green
} else {
    Write-Host "`n[ERROR] Some checks failed." -ForegroundColor Red
    exit 1
}
