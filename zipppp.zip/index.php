<?php
/**
 * PAZINGS INVENTORY & SALES MANAGEMENT SYSTEM
 * Staff & Owner Dashboard: Simple Daily Overview
 * Strict Minimal Blue & White Theme (No Emojis)
 */

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/csrf.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

requireLogin();
$pdo = getDbConnection();
$currentUser = getCurrentUser();

$pageTitle = 'Daily Overview';
$today = date('Y-m-d');
$currentDateFormatted = date('l, F j, Y');

// 1. Calculate Today's Paid Sales and Unpaid Balance directly from DB
$salesStmt = $pdo->prepare("
    SELECT 
        COALESCE(SUM(CASE WHEN payment_status = 'paid' AND business_category = 'water' THEN total_amount ELSE 0 END), 0) AS water_paid,
        COALESCE(SUM(CASE WHEN payment_status = 'paid' AND business_category = 'laundry' THEN total_amount ELSE 0 END), 0) AS laundry_paid,
        COALESCE(SUM(CASE WHEN payment_status = 'paid' THEN total_amount ELSE 0 END), 0) AS paid_sales,
        COALESCE(SUM(CASE WHEN payment_status = 'unpaid' AND business_category = 'water' THEN total_amount ELSE 0 END), 0) AS water_unpaid,
        COALESCE(SUM(CASE WHEN payment_status = 'unpaid' AND business_category = 'laundry' THEN total_amount ELSE 0 END), 0) AS laundry_unpaid,
        COALESCE(SUM(CASE WHEN payment_status = 'unpaid' THEN total_amount ELSE 0 END), 0) AS unpaid_balance,
        SUM(CASE WHEN payment_status = 'unpaid' THEN 1 ELSE 0 END) AS unpaid_count,
        COUNT(*) AS transaction_count
    FROM transactions 
    WHERE transaction_date = ?
");
$salesStmt->execute([$today]);
$sales = $salesStmt->fetch();

$todayPaidSales = (float)($sales['paid_sales'] ?? 0);
$todayWaterPaid = (float)($sales['water_paid'] ?? 0);
$todayLaundryPaid = (float)($sales['laundry_paid'] ?? 0);
$todayUnpaidBalance = (float)($sales['unpaid_balance'] ?? 0);
$todayWaterUnpaid = (float)($sales['water_unpaid'] ?? 0);
$todayLaundryUnpaid = (float)($sales['laundry_unpaid'] ?? 0);
$todayUnpaidCount = (int)($sales['unpaid_count'] ?? 0);
$todayTransCount = (int)($sales['transaction_count'] ?? 0);

// 2. Fetch small list of recent transactions (Latest 6)
$recentStmt = $pdo->prepare("
    SELECT t.id, t.transaction_code, t.business_category, t.transaction_time,
           t.customer_name, t.total_amount, t.payment_status
    FROM transactions t
    WHERE t.transaction_date = ?
    ORDER BY t.transaction_time DESC, t.id DESC
    LIMIT 6
");
$recentStmt->execute([$today]);
$recentTransactions = $recentStmt->fetchAll();

// If no transactions today, fetch latest 6 from any day so the table is informative
if (empty($recentTransactions)) {
    $recentStmt = $pdo->query("
        SELECT t.id, t.transaction_code, t.business_category, t.transaction_time,
               t.customer_name, t.total_amount, t.payment_status
        FROM transactions t
        ORDER BY t.transaction_date DESC, t.transaction_time DESC, t.id DESC
        LIMIT 6
    ");
    $recentTransactions = $recentStmt->fetchAll();
    $isShowingRecentDays = true;
} else {
    $isShowingRecentDays = false;
}

require_once __DIR__ . '/includes/header.php';
?>

<!-- Page Header -->
<div class="page-header">
    <div>
        <h1 class="page-title">Daily Overview</h1>
        <p class="page-subtitle"><?= e($currentDateFormatted) ?></p>
    </div>
    <?php if (isOwner()): ?>
        <div>
            <a href="modules/reports/daily.php" class="btn btn-secondary btn-sm">Full Business Summary</a>
        </div>
    <?php endif; ?>
</div>

<!-- Three Clear Primary Actions -->
<div class="action-grid">
    <a href="modules/water/index.php" class="action-card primary-action">
        Water Refilling
    </a>
    <a href="modules/laundry/index.php" class="action-card primary-action">
        Laundry
    </a>
    <a href="modules/expenses/index.php" class="action-card">
        Expenses
    </a>
</div>

<!-- Today's Paid Sales Banner -->
<div class="overview-banner">
    <div>
        <div class="overview-label">Today's Paid Sales</div>
        <div class="overview-value"><?= formatCurrency($todayPaidSales) ?></div>
    </div>
    <div style="font-size: 0.85rem; color: var(--text-muted); text-align: right;">
        <div>Water: <strong><?= formatCurrency($todayWaterPaid) ?></strong></div>
        <div>Laundry: <strong><?= formatCurrency($todayLaundryPaid) ?></strong></div>
        <div style="margin-top: 2px;"><?= $todayTransCount ?> transaction(s) recorded today</div>
    </div>
</div>

<!-- Compact Unpaid Balance Section -->
<div class="unpaid-banner <?= $todayUnpaidBalance > 0 ? 'has-unpaid' : '' ?>">
    <div>
        <div class="unpaid-label">Unpaid Balance</div>
        <div class="unpaid-value"><?= formatCurrency($todayUnpaidBalance) ?></div>
    </div>
    <div style="font-size: 0.85rem; color: var(--text-muted); text-align: right;">
        <div><?= $todayUnpaidCount ?> unpaid transaction(s)</div>
        <div style="margin-top: 2px; font-size: 0.78rem;">
            Water: <?= formatCurrency($todayWaterUnpaid) ?> &bull; Laundry: <?= formatCurrency($todayLaundryUnpaid) ?>
        </div>
    </div>
</div>

<!-- Small List of Recent Transactions -->
<div class="card">
    <div class="card-header">
        <h2 class="card-title">
            <?= $isShowingRecentDays ? "Recent Transactions" : "Today's Transactions" ?>
        </h2>
        <span style="font-size: 0.8rem; color: var(--text-muted);">
            <?= count($recentTransactions) ?> records
        </span>
    </div>

    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Time</th>
                    <th>Code</th>
                    <th>Category</th>
                    <th>Customer Name</th>
                    <th style="text-align: right;">Amount</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($recentTransactions)): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 24px; color: var(--text-muted);">
                            No transactions recorded yet today. Click <strong>Water Refilling</strong> or <strong>Laundry</strong> above to record a sale.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($recentTransactions as $rt): ?>
                        <tr>
                            <td style="color: var(--text-muted); font-size: 0.82rem;">
                                <?= date('h:i A', strtotime($rt['transaction_time'])) ?>
                            </td>
                            <td><code><?= e($rt['transaction_code']) ?></code></td>
                            <td>
                                <span class="badge badge-<?= e($rt['business_category']) ?>">
                                    <?= ucfirst(e($rt['business_category'])) ?>
                                </span>
                            </td>
                            <td><strong><?= e($rt['customer_name']) ?></strong></td>
                            <td style="text-align: right; font-weight: 700; color: var(--navy);">
                                <?= formatCurrency($rt['total_amount']) ?>
                            </td>
                            <td>
                                <span class="badge badge-<?= $rt['payment_status'] === 'paid' ? 'paid' : 'unpaid' ?>">
                                    <?= ucfirst(e($rt['payment_status'])) ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
