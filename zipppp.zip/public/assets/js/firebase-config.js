/**
 * PAZINGS INVENTORY & SALES MANAGEMENT SYSTEM
 * Firebase Configuration & Service Initializer
 *
 * Compatible with direct file execution (file://) and local/cloud web servers (http://).
 * Credentials from Firebase Console — project: pazings-inventory
 */

window.firebaseConfig = {
  apiKey: "AIzaSyAquzQqnO3C3kU1LW822jyQO-pFWCBumQ8",
  authDomain: "pazings-inventory.firebaseapp.com",
  projectId: "pazings-inventory",
  storageBucket: "pazings-inventory.firebasestorage.app",
  messagingSenderId: "897424469536",
  appId: "1:897424469536:web:f3b9cc600b0aba993a9645",
  measurementId: "G-R2CLRSJ191"
};

// Check if real Firebase credentials have been configured
window.isFirebaseConfigured = function() {
  return window.firebaseConfig &&
         window.firebaseConfig.apiKey &&
         window.firebaseConfig.apiKey !== "YOUR_API_KEY" &&
         window.firebaseConfig.projectId !== "YOUR_PROJECT_ID";
};
