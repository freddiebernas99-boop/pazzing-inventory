# PAZINGS INVENTORY & SALES MANAGEMENT SYSTEM

A clean, responsive, and deployable web-based inventory and daily sales management system designed specifically for **Pazings Laundry Shop and Water Refilling Station**.

This application transitions Pazings away from cumbersome daily Excel encoding into a centralized multi-user cloud system. Staff can record transactions on a phone from the counter, and the owner can instantly review sales totals, expenses, and business performance in real time from any phone or computer.

---

## 1. System Overview & Technology Stack

The application is built as a modern, zero-build client application with native support for **Firebase Cloud Services**:

- **Frontend**: Clean semantic HTML5, modern responsive CSS3, and standard ES Module JavaScript (no heavy build tools or bloated dependencies required).
- **Theme**: Strict professional Blue and White palette (Navy `#123B66`, Primary Blue `#2563EB`, Light Blue `#EAF2FF`, Background `#F5F7FA`, Surface `#FFFFFF`).
- **Typography & Aesthetics**: Clean typography with zero emojis, minimal borders, subtle shadows, and touch-optimized form fields.
- **Hosting**: Firebase Hosting (instant deployment with global CDN and SSL).
- **Database**: Google Cloud Firestore for shared, real-time transaction, expense, rate, and customer data.
- **Authentication**: Firebase Authentication for secure email and password sign-in.
- **Access Control**: Server-enforced `firestore.rules` (Role-Based Access Control protecting rates, financials, PII, and immutable audit trails).
- **Offline / Local Demo Store**: Built-in reactive fallback storage so you can run, test, and encode immediately without waiting for Firebase setup.

---

## 2. Verified Business Modules & Rules

All rates and business logic are derived directly from the Pazings Excel workbooks:

### A. Staff Home Page / Daily Overview
- Page Title: **Daily Overview** with current business date.
- **Today's Total Sales**: Prominently displayed with separate breakdowns for Water Refilling and Laundry.
- **Three Primary Actions**: Quick-access buttons for **Water Refilling**, **Laundry**, and **Expenses**.
- **Recent Transactions**: Compact table showing today's transactions with real-time status badges.
- Keeps settings, rates, and customer management hidden from staff.

### B. Water Refilling Module
- Transaction form: Date (defaults to today), Customer Name (optional / autocomplete), Refill quantity, Delivered quantity, Gallon with Refill quantity, plus optional extra items (Round Cover, Half Gallon).
- **Default Rates**:
  - Refill: **₱30.00**
  - Delivered: **₱35.00**
  - Gallon w/ Refill: **₱210.00**
  - Round Gallon Cover: **₱15.00**
  - Half Gallon Refill: **₱15.00**
- **Dynamic Total**: Real-time calculation displayed **immediately above the Save Transaction button**.
- **Rate Snapshot Protection**: Saves unit price at the time of purchase so future rate changes never alter historical records.
- **Transactions Table**: Compact day sheet below the form with date filters and payment status toggles (`Paid` / `Unpaid`).

### C. Laundry Shop Module
- Transaction form: Date (defaults to today), Customer Name (required), Regular loads, Special loads, Comforter loads, Detergent packs, and Fab Con packs.
- **Default Rates**:
  - Regular Load: **₱175.00**
  - Special Load: **₱205.00**
  - Comforter Load: **₱235.00**
  - Detergent Pack: **₱10.00**
  - Fab Con Pack: **₱10.00**
- **Dynamic Total**: Updates in real time immediately above the Save Transaction button.
- **Transactions Table**: Compact day sheet with customer names, item summaries, and status.

### D. Expenses Module
- Expense form: Date, Business Category (**Water Refilling**, **Laundry**, or **Shared Business Expense**), Description, optional Quantity and Unit Price (auto-computes amount), Total Amount, and optional Notes / OR number.
- Recorded expenses table: Filterable by date and category with instant sum calculation.

### E. Reports & Overall Daily Summary
- **Daily Financial Statement**:
  - Gross Water Refilling Sales + Gross Laundry Sales = **Total Gross Sales**
  - Water Expenses + Laundry Expenses + Shared Expenses = **Grand Total Expenses**
  - **Estimated Net Profit** = Total Gross Sales &minus; Grand Total Expenses
- **Shared Expenses Breakdown**: Itemized table of overhead items (e.g., fuel, supplies, meals).
- **Excel CSV Export**: One-click download with UTF-8 BOM encoding for seamless Microsoft Excel compatibility.
- **Print / PDF**: Clean, print-optimized stylesheet (`assets/css/print.css`) that hides buttons and navigation bars.

### F. Owner-Only Administration
- **Customer Directory**: Tracks lifetime spend, total orders, contact numbers, and delivery addresses.
- **Rates Management**: Allows updating base prices for water and laundry for future transactions.
- **Staff Accounts**: Owner can create staff logins and monitor active accounts.

---

## 3. Quick Start: Local Testing (Zero Setup)

You do **not** need Node.js, PHP, or MySQL to run and test the application locally.

### Method 1: Double-Click Launcher
1. Open the folder: `C:\PAZINGS-INVENTORY`
2. Double-click **`start_server.bat`**.
3. It launches the built-in Windows PowerShell local server and opens your browser to:  
   👉 **`http://localhost:8000/`**

### Method 2: Local Demo
Without Firebase configuration, choose Staff or Admin to open a local demo. Demo data stays in that browser and is not protected by account authentication; do not use this mode for shared or production data.

### Legacy PHP/MySQL Edition
The repository also includes a separate PHP/MySQL edition. After configuring the database environment variables, run `php database/db_setup.php`, then run `php database/create_owner.php` from a trusted terminal. The CLI-only bootstrap creates a random one-time owner password and refuses to run if any account already exists; no default user credentials are seeded.

---

## 4. Connecting to Your Live Firebase Project

When you are ready to connect to Google Cloud Firestore and Firebase Authentication:

### Step 1: Create a Free Firebase Project
1. Go to the [Firebase Console](https://console.firebase.google.com/) and sign in with your Google account.
2. Click **Add project** and enter a name (e.g. `pazings-inventory`).
3. (Optional) Disable Google Analytics for simplicity, then click **Create project**.

### Step 2: Enable Firebase Authentication
1. In the Firebase Console left sidebar, click **Build** > **Authentication**.
2. Click **Get Started**, then select **Email/Password**.
3. Turn on the **Email/Password** switch and click **Save**.
4. Under **Users**, create your first owner account with a unique email and strong password. Do not reuse credentials from an older deployment.

### Step 3: Create Cloud Firestore Database
1. In the sidebar, click **Build** > **Firestore Database**.
2. Click **Create database**.
3. Choose a location closest to you (e.g., `asia-southeast1` for Singapore/Philippines).
4. Start in **Production mode** (we provide the hardened `firestore.rules`).

### Step 4: Copy Your Web App Credentials
1. In the Firebase Console, click the **Gear icon (Project Settings)** next to Project Overview.
2. Under the **General** tab, scroll down to **Your apps** and click the **Web icon (`</>`)**.
3. Enter an app nickname (e.g. `Pazings Web`) and click **Register app**.
4. Firebase will display your `firebaseConfig` object:
   ```javascript
   const firebaseConfig = {
     apiKey: "AIzaSy...",
     authDomain: "pazings-inventory.firebaseapp.com",
     projectId: "pazings-inventory",
     storageBucket: "pazings-inventory.appspot.com",
     messagingSenderId: "...",
     appId: "..."
   };
   ```
5. Open `public/assets/js/firebase-config.js` in your editor and replace the placeholder values with your keys.

### Step 5: Bootstrap the First Owner Profile
1. In Firebase Authentication, copy the new owner's **User UID**.
2. In Cloud Firestore, create a document in the `users` collection with the document ID set to that UID.
3. Add these fields:
   - `email` (string): the owner's Firebase Authentication email
   - `fullName` (string): the owner's display name
   - `role` (string): `owner`
   - `status` (string): `active`
   - `createdAt` (timestamp): the current time
4. Deploy the included Firestore rules. The first owner profile must be created through the Firebase Console; clients cannot grant themselves a role.
5. Sign in using the Owner option. The owner can create individual Staff accounts from **Staff Accounts**; passwords are sent directly to Firebase Authentication and are not stored in Firestore.

For each staff account, use a unique email and password. The application assigns staff access based on the account's Firestore profile, not its email address. Owner accounts must be provisioned separately by a trusted administrator.

---

## 5. Deploying to Firebase Hosting

To publish your application to the web with your own free `.web.app` and `.firebaseapp.com` URLs:

### Step 1: Install Firebase CLI (if not already installed)
From a terminal or command prompt:
```bash
npm install -g firebase-tools
```

### Step 2: Login and Deploy
```bash
cd C:\PAZINGS-INVENTORY

# Login to your Google account
firebase login

# Link to your Firebase project
firebase use --add

# Deploy Hosting, Firestore rules, and Firestore indexes
firebase deploy
```

Once the command completes, Firebase will print your live URL:
```
Hosting URL: https://pazings-inventory.web.app
```
You and your staff can now open this link on any smartphone or computer to manage sales and inventory anywhere!

---

## 6. Project File Structure

```text
PAZINGS-INVENTORY/
├── public/                       # Deployed web root for Firebase Hosting
│   ├── index.html                # Single-page application UI (clean blue-and-white, zero emojis)
│   └── assets/
│       ├── css/
│       │   ├── style.css         # Modern, responsive stylesheet (#123B66, #2563EB, #F5F7FA)
│       │   └── print.css         # Print & PDF stylesheet for clean business reports
│       └── js/
│           ├── firebase-config.js# Firebase configuration & project credentials
│           └── app.js            # Core application engine (Firestore SDK + local store fallback)
├── database/                     # Original database references & seed scripts
├── firestore.rules               # Production Firestore Security Rules (RBAC, PII shielding)
├── firestore.indexes.json        # Composite indexes for Firestore date/category queries
├── firebase.json                 # Firebase Hosting & Firestore deployment configuration
├── index.html                    # Root redirect to public/index.html
├── server.ps1                    # Built-in lightweight Windows local static server
├── start_server.bat              # 1-click Windows server launcher
└── README.md                     # Comprehensive documentation & deployment guide
```

---

## 7. Security & Compliance Notes
- **Firestore Security Rules**: Fully configured in `firestore.rules` to enforce that staff cannot delete transactions or modify rates. Financial amounts cannot be negative or manipulated.
- **Authentication**: Firebase email/password accounts are individual. Firestore user profiles determine active status and role; email naming never grants access. The first owner profile is bootstrapped manually in Firebase Console.
- **Migration warning**: The previous shared PIN/passphrase and shared Firebase accounts are no longer supported. Disable/delete those old Firebase Authentication accounts and the `settings/security_credentials` document, create a new owner account and profile, and create fresh individual staff accounts before using the cloud app.
- **Legacy PHP/MySQL migration**: Older databases may still contain accounts from the former default seed. Change or remove those passwords before exposing an existing installation.
- **Audit Logging**: User transactions and actions generate audit logs that cannot be modified or deleted.
- **No Build Step Required**: Uses standard browser ES Modules, eliminating fragile dependency chains and node version conflicts.
